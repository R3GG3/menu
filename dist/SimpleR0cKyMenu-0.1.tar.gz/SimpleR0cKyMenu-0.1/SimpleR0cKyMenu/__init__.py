from menu import Menu
from exceptions import IncorrectArguments

__author__ = "R0cKy"